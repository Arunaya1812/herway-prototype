export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getNearestPoliceStations } from "@/lib/ml-data";

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { latitude, longitude, selectedRoute } = await request.json();

    if (!latitude || !longitude) {
      return NextResponse.json(
        { error: "Missing location data" },
        { status: 400 }
      );
    }

    // Auto-detect nearest city for police station lookup
    const distToDelhi = Math.abs(latitude - 28.6139) + Math.abs(longitude - 77.2090);
    const distToMumbai = Math.abs(latitude - 19.0760) + Math.abs(longitude - 72.8777);
    const city = distToDelhi < distToMumbai ? "delhi" : "mumbai";

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      include: { emergencyContacts: true },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    if (user.emergencyContacts.length === 0) {
      return NextResponse.json(
        { error: "No emergency contacts configured" },
        { status: 400 }
      );
    }

    // Get nearest police stations
    const nearestPoliceStations = getNearestPoliceStations(
      latitude,
      longitude,
      city,
      3
    );

    // Prepare emergency alert data
    const emergencyData = {
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      location: { lat: latitude, lon: longitude },
      route: selectedRoute,
      city,
      timestamp: new Date().toISOString(),
      nearestPoliceStations,
      emergencyContacts: user.emergencyContacts,
    };

    // Send emails to emergency contacts
    const emergencyContactEmails = user.emergencyContacts
      .filter((contact) => contact.email)
      .map((contact) => contact.email);

    if (emergencyContactEmails.length > 0) {
      // Send SOS emails to emergency contacts
      for (const contactEmail of emergencyContactEmails) {
        await sendSOSEmail(
          contactEmail,
          emergencyData,
          "emergency-contact"
        );
      }
    }

    // Send emails to nearest police stations
    for (const station of nearestPoliceStations) {
      if (station.contact || station.email) {
        const policeEmail = station.email || deriveEmailFromPhone(station.contact);
        if (policeEmail) {
          await sendSOSEmail(
            policeEmail,
            emergencyData,
            "police-station",
            station.name
          );
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: "SOS alert sent successfully",
      contactsNotified: emergencyContactEmails.length,
      policeStationsNotified: nearestPoliceStations.length,
    });
  } catch (error) {
    console.error("SOS error:", error);
    return NextResponse.json(
      { error: "Internal server error", details: String(error) },
      { status: 500 }
    );
  }
}

async function sendSOSEmail(
  recipientEmail: string,
  emergencyData: any,
  type: "emergency-contact" | "police-station",
  stationName?: string
) {
  try {
    const isPolice = type === "police-station";
    
    const htmlBody = isPolice
      ? generatePoliceEmailHTML(emergencyData, stationName || "Police Station")
      : generateContactEmailHTML(emergencyData);

    const appUrl = process.env.NEXTAUTH_URL || "https://herway.abacusai.app";
    const appName = new URL(appUrl).hostname.split(".")[0];
    const senderEmail = `noreply@${new URL(appUrl).hostname}`;

    const response = await fetch(
      "https://apps.abacus.ai/api/sendNotificationEmail",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deployment_token: process.env.ABACUSAI_API_KEY,
          app_id: process.env.WEB_APP_ID,
          notification_id: isPolice
            ? process.env.NOTIF_ID_POLICE_EMERGENCY_ALERT
            : process.env.NOTIF_ID_EMERGENCY_SOS_ALERT,
          subject: isPolice
            ? `🚨 EMERGENCY ALERT: User Assistance Required`
            : `🚨 EMERGENCY SOS: Your contact needs help`,
          body: htmlBody,
          is_html: true,
          recipient_email: recipientEmail,
          sender_email: senderEmail,
          sender_alias: "HerWay Emergency",
        }),
      }
    );

    const result = await response.json();
    if (!result.success) {
      console.error(`Failed to send SOS email to ${recipientEmail}:`, result);
    }
  } catch (error) {
    console.error(`Error sending SOS email:`, error);
  }
}

function generateContactEmailHTML(emergencyData: any): string {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9fafb;">
      <div style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); padding: 30px; text-align: center; color: white; border-radius: 8px 8px 0 0;">
        <h1 style="margin: 0; font-size: 28px;">🚨 EMERGENCY ALERT</h1>
      </div>
      <div style="padding: 30px; background: white;">
        <p style="font-size: 16px; color: #1f2937; margin-bottom: 20px;">
          <strong>${emergencyData.userName}</strong> has triggered an emergency SOS alert.
        </p>
        <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #991B1B;"><strong>📍 Last Known Location:</strong></p>
          <p style="margin: 5px 0 0 0; color: #991B1B;">Latitude: ${emergencyData.location.lat.toFixed(4)}, Longitude: ${emergencyData.location.lon.toFixed(4)}</p>
        </div>
        <div style="background: #F3F4F6; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #374151;"><strong>⏰ Time:</strong> ${new Date(emergencyData.timestamp).toLocaleString()}</p>
          <p style="margin: 10px 0 0 0; color: #374151;"><strong>📱 City:</strong> ${emergencyData.city.toUpperCase()}</p>
          <p style="margin: 10px 0 0 0; color: #374151;"><strong>📧 Contact Email:</strong> ${emergencyData.userEmail}</p>
        </div>
        <div style="background: #E0F2FE; border-left: 4px solid #0EA5E9; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #0C4A6E;"><strong>👮 Nearest Police Stations:</strong></p>
          <ul style="margin: 10px 0 0 0; padding-left: 20px; color: #0C4A6E;">
            ${emergencyData.nearestPoliceStations.map((station: any) => 
              `<li>${station.name} - ${station.distance_km.toFixed(1)}km away (${station.contact})</li>`
            ).join("")}
          </ul>
        </div>
        <div style="background: #F0FDF4; border-left: 4px solid #10B981; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0 0 10px 0; color: #065F46;"><strong>🛡️ Safety Tips:</strong></p>
          <ul style="margin: 0; padding-left: 20px; color: #065F46; font-size: 14px;">
            <li>Keep your phone charged and location sharing enabled</li>
            <li>Move to a safe, well-lit area if possible</li>
            <li>Stay calm and alert to your surroundings</li>
            <li>Contact nearest police station immediately</li>
          </ul>
        </div>
        <p style="font-size: 12px; color: #6B7280; margin-top: 20px; text-align: center;">
          This is an automated emergency alert from HerWay Safety System.
        </p>
      </div>
    </div>
  `;
}

function generatePoliceEmailHTML(emergencyData: any, stationName: string): string {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9fafb;">
      <div style="background: linear-gradient(135deg, #DC2626 0%, #7F1D1D 100%); padding: 30px; text-align: center; color: white; border-radius: 8px 8px 0 0;">
        <h1 style="margin: 0; font-size: 28px;">🚨 EMERGENCY ASSISTANCE REQUEST</h1>
        <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.9;">Priority: HIGH</p>
      </div>
      <div style="padding: 30px; background: white;">
        <p style="font-size: 14px; color: #666; background: #fff3cd; padding: 10px; border-radius: 4px; margin-bottom: 20px;">
          ⚠️ <strong>This is a priority emergency alert. Please respond immediately.</strong>
        </p>
        <div style="background: #FEE2E2; border-left: 4px solid #DC2626; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #991B1B;"><strong>🆘 Emergency Details:</strong></p>
          <p style="margin: 10px 0 0 0; color: #991B1B;"><strong>Name:</strong> ${emergencyData.userName}</p>
          <p style="margin: 5px 0 0 0; color: #991B1B;"><strong>Email:</strong> ${emergencyData.userEmail}</p>
        </div>
        <div style="background: #FEE2E2; border-left: 4px solid #DC2626; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #991B1B;"><strong>📍 Last Known Location:</strong></p>
          <p style="margin: 5px 0 0 0; color: #991B1B;">Latitude: ${emergencyData.location.lat.toFixed(6)}<br/>Longitude: ${emergencyData.location.lon.toFixed(6)}</p>
          <p style="margin: 10px 0 0 0; color: #991B1B; font-size: 12px;">
            <a href="https://maps.google.com/?q=${emergencyData.location.lat},${emergencyData.location.lon}" style="color: #DC2626; text-decoration: underline;">View on Google Maps</a>
          </p>
        </div>
        <div style="background: #F3F4F6; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #374151;"><strong>⏰ Alert Time:</strong> ${new Date(emergencyData.timestamp).toLocaleString()}</p>
          <p style="margin: 10px 0 0 0; color: #374151;"><strong>📱 City:</strong> ${emergencyData.city.toUpperCase()}</p>
          <p style="margin: 10px 0 0 0; color: #374151;"><strong>🚨 Status:</strong> Active Emergency</p>
        </div>
        <div style="background: #E0F2FE; border-left: 4px solid #0EA5E9; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #0C4A6E;"><strong>📱 Recommended Actions:</strong></p>
          <ul style="margin: 10px 0 0 0; padding-left: 20px; color: #0C4A6E; font-size: 14px;">
            <li>Dispatch officers to the provided coordinates</li>
            <li>Call the person at the provided contact if available</li>
            <li>Cross-reference with other emergency services if needed</li>
            <li>Monitor this location for incident updates</li>
          </ul>
        </div>
        <p style="font-size: 12px; color: #6B7280; margin-top: 20px; text-align: center;">
          This is an automated emergency alert from the HerWay Safety System. Please verify the information and take appropriate action.
        </p>
      </div>
    </div>
  `;
}

function deriveEmailFromPhone(phone: string): string {
  // Extract numbers from phone
  const numbers = phone.replace(/\D/g, "");
  const last6 = numbers.slice(-6);
  return `emergency${last6}@police.local`;
}
