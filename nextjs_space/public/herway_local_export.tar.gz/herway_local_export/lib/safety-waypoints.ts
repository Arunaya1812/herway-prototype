/**
 * Uses the XGBoost safety grid to find safe waypoints for route diversification.
 * When OSRM returns only one route, we pick a high-safety waypoint
 * near the midpoint corridor and request a detour route through it.
 *
 * This is ML-driven: waypoint selection is based on baseSafetyScore
 * from the XGBoost-trained grid cells in the database.
 */

import { prisma } from "@/lib/prisma";

interface SafeWaypoint {
  lat: number;
  lon: number;
  safety: number;
}

/**
 * Find the best safe waypoint between two points.
 *
 * Strategy:
 * 1. Define a corridor between start and end (perpendicular offset from midpoint)
 * 2. Query grid cells in that corridor
 * 3. Pick the cell with highest baseSafetyScore that is offset enough
 *    from the direct line to force a genuinely different route.
 */
export async function findSafeWaypoint(
  startLat: number, startLon: number,
  endLat: number, endLon: number,
): Promise<SafeWaypoint | null> {
  const midLat = (startLat + endLat) / 2;
  const midLon = (startLon + endLon) / 2;

  // Direction vector from start to end
  const dLat = endLat - startLat;
  const dLon = endLon - startLon;
  const dist = Math.sqrt(dLat * dLat + dLon * dLon);
  if (dist < 0.005) return null; // too close, no detour possible

  // Perpendicular direction (rotated 90 degrees)
  const perpLat = -dLon / dist;
  const perpLon = dLat / dist;

  // Search radius: 20-40% of the distance, offset perpendicular to the direct line
  // This ensures the waypoint forces a genuinely different path
  const offsetMagnitude = dist * 0.25; // offset ~25% of distance perpendicular

  // Two candidate waypoint centers: one on each side of the direct line
  const candidates = [
    { lat: midLat + perpLat * offsetMagnitude, lon: midLon + perpLon * offsetMagnitude },
    { lat: midLat - perpLat * offsetMagnitude, lon: midLon - perpLon * offsetMagnitude },
    // Also try 1/3 and 2/3 along the route with offsets
    { lat: startLat + dLat * 0.33 + perpLat * offsetMagnitude * 0.8, lon: startLon + dLon * 0.33 + perpLon * offsetMagnitude * 0.8 },
    { lat: startLat + dLat * 0.67 - perpLat * offsetMagnitude * 0.8, lon: startLon + dLon * 0.67 - perpLon * offsetMagnitude * 0.8 },
  ];

  // Search radius around each candidate (in degrees, ~2-3km)
  const searchRadius = Math.max(0.015, Math.min(0.04, offsetMagnitude * 0.6));

  let bestWaypoint: SafeWaypoint | null = null;

  for (const center of candidates) {
    try {
      const cells = await prisma.safetyGridCell.findMany({
        where: {
          city: "delhi",
          latitude: { gte: center.lat - searchRadius, lte: center.lat + searchRadius },
          longitude: { gte: center.lon - searchRadius, lte: center.lon + searchRadius },
        },
        select: { latitude: true, longitude: true, baseSafetyScore: true },
        orderBy: { baseSafetyScore: "desc" },
        take: 5,
      });

      for (const cell of cells) {
        // Ensure the waypoint is meaningfully offset from the direct line
        const crossDist = pointToLineDist(
          cell.latitude, cell.longitude,
          startLat, startLon, endLat, endLon
        );
        // Must be at least 0.005 degrees (~500m) off the direct line
        if (crossDist < 0.005) continue;

        if (!bestWaypoint || cell.baseSafetyScore > bestWaypoint.safety) {
          bestWaypoint = { lat: cell.latitude, lon: cell.longitude, safety: cell.baseSafetyScore };
        }
      }
    } catch (err) {
      console.error("[SafeWaypoint] DB query error:", err);
    }
  }

  return bestWaypoint;
}

/** Distance from point (px,py) to line segment (ax,ay)-(bx,by) in degree units */
function pointToLineDist(
  px: number, py: number,
  ax: number, ay: number,
  bx: number, by: number
): number {
  const dx = bx - ax, dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.sqrt((px - ax) ** 2 + (py - ay) ** 2);
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / lenSq));
  const projX = ax + t * dx, projY = ay + t * dy;
  return Math.sqrt((px - projX) ** 2 + (py - projY) ** 2);
}
